package org.techtown.weathering_with_you;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    final String TAG = "MainActivity";

    Converter converter = new Converter();
    WeatherStatus weatherStatus = new WeatherStatus();

    double latitude;
    double longitude;

    TextView mainAddressTextView;
    ImageView mainWeatherIconImageView;
    TextView mainWeatherTemperatureTextView;
    TextView mainLowHighTemperatureTextView;
    TextView mainHumidityTextView;
    TextView mainPrecipitationProbabilityTextView;
    TextView mainPrecipitationTextView;
    TextView weatherInformationTextView;

    ListView weatherListView;

    int timeIndex1, timeIndex2;

    String[] timeText = {
            "오전6시", "오전9시", "오후12시", "오후3시", "오후6시", "오후9시", "오전12시"

    };

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainAddressTextView = findViewById(R.id.mainAddressTextView);
        mainWeatherIconImageView = findViewById(R.id.mainWeatherIconImageView);
        mainWeatherTemperatureTextView = findViewById(R.id.mainWeatherTemperatureTextView);
        mainLowHighTemperatureTextView = findViewById(R.id.mainLowHighTemperatureTextView);
        mainHumidityTextView = findViewById(R.id.mainHumidityTextView);
        mainPrecipitationProbabilityTextView = findViewById(R.id.mainPrecipitationProbabilityTextView);
        mainPrecipitationTextView = findViewById(R.id.mainPrecipitationTextView);
        weatherInformationTextView = findViewById(R.id.weatherInformationTextView);
        weatherListView = findViewById(R.id.weatherListView);

        latitude = GpsTracker.getInstance(this).getLatitude();
        longitude = GpsTracker.getInstance(this).getLongitude();

        GetWeather getWeather = new GetWeather();
        try {
            weatherStatus = getWeather.execute(latitude, longitude).get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        SimpleDateFormat simpleTime = new SimpleDateFormat("HH", Locale.KOREA);
        referenceIndex(Integer.parseInt(simpleTime.format(new Date())));

        String address = GpsTracker.getInstance(this).getAddress();
        Log.d(TAG, address);
        mainAddressTextView.setText(address);

        int weatherIcon = Integer.parseInt(converter.getWeatherIconIdAndText(0, weatherStatus.getSky().get(timeIndex1), weatherStatus.getPty().get(timeIndex1)));
        mainWeatherIconImageView.setImageResource(weatherIcon);

        int nowTemperature = Math.round(weatherStatus.getT3h().get(timeIndex1));
        mainWeatherTemperatureTextView.setText(nowTemperature+"");

        int lowTemperature = Math.round(weatherStatus.getTmn().get(0));
        int highTemperature = Math.round(weatherStatus.getTmx().get(0));
        mainLowHighTemperatureTextView.setText(lowTemperature+"  "+highTemperature);

        String weatherInformationText = converter.getWeatherIconIdAndText(1, weatherStatus.getSky().get(timeIndex1), weatherStatus.getPty().get(timeIndex1));
        weatherInformationTextView.setText(weatherInformationText);

        int humidity = Math.round(weatherStatus.getReh().get(timeIndex1));
        mainHumidityTextView.setText("습도\n"+humidity+"%");

        int precipitationProbability = Math.round(weatherStatus.getPop().get(timeIndex1));
        mainPrecipitationProbabilityTextView.setText("강수확률\n"+precipitationProbability+"%");

        int precipitation = Math.round(weatherStatus.getR06().get(timeIndex2));
        mainPrecipitationTextView.setText("강수량\n"+precipitation+"%");

        ArrayList<HashMap<String, Object>> weatherDataList = new ArrayList<HashMap<String, Object>>();

        for(int i =0; i<7; i++){
            HashMap<String, Object> map = new HashMap<String, Object>();
            map.put("sky", Integer.parseInt(converter.getWeatherIconIdAndText(0, weatherStatus.getSky().get(i), weatherStatus.getPty().get(i))));
            map.put("time", timeText[i]);
            map.put("temp", weatherStatus.getT3h().get(i));

            weatherDataList.add(map);
        }

        String[] keys = {"sky", "time", "temp"};

        int[] ids = { R.id.weatherListImageView, R.id.weatherListTimeTextView, R.id.weatherListTempTextView};

        SimpleAdapter adapter = new SimpleAdapter(this, weatherDataList, R.layout.weatherlistview, keys, ids);
        weatherListView.setAdapter(adapter);


    }

    private void referenceIndex(int nowTime){

        int index1 = 0;
        int index2 = 0;

        if(nowTime>6 && nowTime <= 9){
            index1 = 0;
            index2 = 0;
        } else if(nowTime>9 && nowTime<=12){
            index1 = 1;
            index2 = 0;
        } else if(nowTime>12 && nowTime<=15){
            index1 = 2;
            index2 = 1;
        } else if(nowTime>15 && nowTime<=18){
            index1 = 3;
            index2 = 1;
        } else if(nowTime>18 && nowTime<=21){
            index1 = 4;
            index2 = 2;
        } else if(nowTime>21 && nowTime<=24){
            index1 = 5;
            index2 = 2;
        } else {
            index1 = 6;
            index2 = 3;
        }

        timeIndex1 = index1;
        timeIndex2 = index2;
    }

}