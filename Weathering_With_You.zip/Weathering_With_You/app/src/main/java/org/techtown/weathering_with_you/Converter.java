package org.techtown.weathering_with_you;

public class Converter {

    String getWeatherIconIdAndText(int type, float skyCode, float ptyCode){

        int image = 0;
        String text = "";
        switch ((int) skyCode){
            case 1:
                image = R.drawable.sun;
                text = "현재 하늘은 맑아요!";
                break;
            case 2:
            case 3:
                image = R.drawable.suncloud;
                text = "현재 하늘은 구름이 많아요!";
                break;
            case 4:
                image = R.drawable.cloud;
                text = "현재 하늘은 흐려요!";
        }

        switch ((int) ptyCode){
            case 1:
            case 4:
            case 5:
                image = R.drawable.rain;
                text = "현재 비가와요!";
                break;
            case 2:
            case 6:
                image = R.drawable.snowrain;
                text = "현재 비와 눈이 같이와요!";
                break;
            case 3:
            case 7:
                image = R.drawable.snow;
                text = "현재 눈이와요!";
                break;
        }
        if(type == 0)
            return Integer.toString(image);
        else
            return text;
    }
}
